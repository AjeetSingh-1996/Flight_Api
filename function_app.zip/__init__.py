import logging
import azure.functions as func
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("🚀 Hot Path API Triggered!")

    try:
        # JSON Payload Read
        req_body = req.get_json()
        logging.info(f"📩 Received Data: {req_body}")

        # Validate Request
        if not req_body or "message" not in req_body:
            return func.HttpResponse(
                json.dumps({"error": "Invalid request. 'message' field is required."}),
                status_code=400,
                mimetype="application/json"
            )

        # Processing Data (Example: Saving to Blob Storage / Event Hub - Future Step)
        processed_message = {
            "status": "success",
            "message": req_body["message"],
            "processed_at": "Azure Function Hot Path API"
        }

        return func.HttpResponse(
            json.dumps(processed_message),
            status_code=200,
            mimetype="application/json"
        )
    
    except Exception as e:
        logging.error(f"❌ Error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": "Internal Server Error"}),
            status_code=500,
            mimetype="application/json"
        )